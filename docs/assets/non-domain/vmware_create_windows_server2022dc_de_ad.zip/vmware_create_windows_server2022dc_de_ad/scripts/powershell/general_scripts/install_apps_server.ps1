# Install Apps

choco install -y microsoft-edge
choco install -y --package-parameters=/SSHServerFeature openssh
choco install -y powershell-core
choco install -y 7zip
choco install -y putty
choco install -y winscp